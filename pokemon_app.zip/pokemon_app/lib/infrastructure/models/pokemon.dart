// lib/infrastructure/models/pokemon.dart

/// Modelo principal: mapea la respuesta de
/// https://pokeapi.co/api/v2/pokemon/{id}
class Pokemon {
  final int id;
  final String name;
  final Sprites sprites;

  Pokemon({
    required this.id,
    required this.name,
    required this.sprites,
  });

  /// Constructor con nombre que convierte el Map de Dio en un objeto tipado.
  factory Pokemon.fromJson(Map<String, dynamic> json) => Pokemon(
        id: json['id'],
        name: json['name'],
        sprites: Sprites.fromJson(json['sprites']),
      );
}

/// Subclase para las imágenes del Pokémon.
/// Son nullable porque algunos Pokémon no tienen sprite trasero.
class Sprites {
  final String? frontDefault;
  final String? backDefault;

  Sprites({
    this.frontDefault,
    this.backDefault,
  });

  factory Sprites.fromJson(Map<String, dynamic> json) => Sprites(
        frontDefault: json['front_default'],
        backDefault: json['back_default'],
      );
}
