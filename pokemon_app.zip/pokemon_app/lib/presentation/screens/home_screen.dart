// lib/presentation/screens/home_screen.dart

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../infrastructure/models/pokemon.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Instancia de Dio para las peticiones HTTP
  final Dio dio = Dio();

  int pokemonId = 0;
  Pokemon? pokemon;

  /// Incrementa el id, hace la petición GET y actualiza el estado.
  Future<void> getPokemon() async {
    pokemonId++;

    try {
      final response =
          await dio.get('https://pokeapi.co/api/v2/pokemon/$pokemonId');

      // response.data ya viene como Map<String, dynamic>
      pokemon = Pokemon.fromJson(response.data);
    } catch (e) {
      debugPrint('Error al obtener el Pokémon $pokemonId: $e');
    }

    // Evita llamar setState si el widget ya no está en pantalla
    if (!mounted) return;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getPokemon(); // Carga el primer Pokémon al iniciar
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pokémon - HTTP GET con Dio'),
      ),
      body: Center(
        child: pokemon == null
            ? const CircularProgressIndicator()
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // ID y nombre
                  Text(
                    '#${pokemon!.id} - ${pokemon!.name}',
                    style: const TextStyle(fontSize: 24),
                  ),
                  const SizedBox(height: 20),

                  // Imagen frontal
                  if (pokemon!.sprites.frontDefault != null)
                    Image.network(
                      pokemon!.sprites.frontDefault!,
                      width: 150,
                      height: 150,
                    ),

                  // Imagen trasera
                  if (pokemon!.sprites.backDefault != null)
                    Image.network(
                      pokemon!.sprites.backDefault!,
                      width: 150,
                      height: 150,
                    ),
                ],
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: getPokemon, // Avanza al siguiente Pokémon
        child: const Icon(Icons.navigate_next),
      ),
    );
  }
}
