# pokemon_app

App en Flutter que consume la PokeAPI con Dio (HTTP GET).

## Cómo correrla

1. Descomprime el ZIP y abre la carpeta `pokemon_app` en VS Code.
2. Abre la terminal de VS Code (Ctrl + Ñ o Ctrl + `) y ejecuta **una sola vez**:
   - Windows: `.\preparar.bat`
   - macOS / Linux: `./preparar.sh`

   Esto ejecuta `flutter create .` (genera android/, ios/, web/, windows/...
   sin modificar `lib/`) y `flutter pub get` (descarga Dio).
3. Elige un dispositivo abajo a la derecha en VS Code (emulador, Chrome o Windows)
   y presiona **F5**, o ejecuta `flutter run`.

## Estructura

```
lib/
├── main.dart
├── infrastructure/models/pokemon.dart
└── presentation/screens/home_screen.dart
```

## Nota para macOS (escritorio)
Si corres en macOS, agrega en `macos/Runner/DebugProfile.entitlements`:
`<key>com.apple.security.network.client</key><true/>`
