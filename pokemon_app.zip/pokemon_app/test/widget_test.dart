import 'package:flutter_test/flutter_test.dart';
import 'package:pokemon_app/main.dart';

void main() {
  testWidgets('La app arranca', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    expect(find.text('Pokémon - HTTP GET con Dio'), findsOneWidget);
  });
}
