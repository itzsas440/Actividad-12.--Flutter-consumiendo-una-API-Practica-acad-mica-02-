#!/bin/sh
# Genera las carpetas de plataforma (android, ios, web, macos...) sin tocar lib/
flutter create . --project-name pokemon_app
flutter pub get
echo "Listo. Ahora presiona F5 en VS Code o ejecuta: flutter run"
