@echo off
REM Genera las carpetas de plataforma (android, ios, web, windows...) sin tocar lib/
call flutter create . --project-name pokemon_app
call flutter pub get
echo.
echo Listo. Ahora presiona F5 en VS Code o ejecuta: flutter run
pause
