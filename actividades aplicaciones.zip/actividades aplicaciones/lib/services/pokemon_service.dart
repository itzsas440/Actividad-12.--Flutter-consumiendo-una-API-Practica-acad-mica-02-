﻿import 'package:dio/dio.dart';
import '../models/pokemon.dart';

class PokemonService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://pokeapi.co/api/v2',
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 10),
  ));

  /// [idOrName] puede ser un número (1) o un nombre (pikachu).
  Future<Pokemon> getPokemon(String idOrName) async {
    try {
      final res = await _dio.get('/pokemon/${idOrName.toLowerCase().trim()}/');
      return Pokemon.fromJson(res.data as Map<String, dynamic>);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        throw Exception('No se encontró el Pokémon "$idOrName"');
      }
      throw Exception('Error de red: revisa tu conexión');
    }
  }
}
