﻿class PokemonStat {
  final String name;
  final int value;
  PokemonStat(this.name, this.value);
}

class Pokemon {
  final int id;
  final String name;
  final double height; // metros
  final double weight; // kg
  final String imageUrl;
  final List<String> types;
  final List<String> abilities;
  final List<PokemonStat> stats;

  Pokemon({
    required this.id,
    required this.name,
    required this.height,
    required this.weight,
    required this.imageUrl,
    required this.types,
    required this.abilities,
    required this.stats,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    final sprites = json['sprites'] as Map<String, dynamic>;
    final artwork = sprites['other']?['official-artwork']?['front_default'];
    return Pokemon(
      id: json['id'],
      name: json['name'],
      height: (json['height'] as num) / 10,
      weight: (json['weight'] as num) / 10,
      imageUrl: artwork ?? sprites['front_default'] ?? '',
      types: (json['types'] as List)
          .map((t) => t['type']['name'] as String)
          .toList(),
      abilities: (json['abilities'] as List)
          .map((a) => a['ability']['name'] as String)
          .toList(),
      stats: (json['stats'] as List)
          .map((s) => PokemonStat(s['stat']['name'], s['base_stat']))
          .toList(),
    );
  }

  String get displayName => name[0].toUpperCase() + name.substring(1);
}
