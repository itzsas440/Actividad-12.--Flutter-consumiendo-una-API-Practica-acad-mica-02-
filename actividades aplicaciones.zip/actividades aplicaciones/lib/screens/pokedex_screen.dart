﻿import 'package:flutter/material.dart';
import '../models/pokemon.dart';
import '../services/pokemon_service.dart';

const _typeColors = <String, Color>{
  'fire': Colors.orange,
  'water': Colors.blue,
  'grass': Colors.green,
  'electric': Colors.amber,
  'psychic': Colors.pink,
  'ice': Colors.cyan,
  'dragon': Colors.indigo,
  'dark': Colors.brown,
  'fairy': Colors.pinkAccent,
  'poison': Colors.purple,
  'ground': Color(0xFFB8860B),
  'rock': Color(0xFF8D6E63),
  'bug': Colors.lightGreen,
  'ghost': Colors.deepPurple,
  'fighting': Colors.redAccent,
  'steel': Colors.blueGrey,
  'flying': Colors.lightBlue,
};

Color typeColor(String t) => _typeColors[t] ?? Colors.grey;

class PokedexScreen extends StatefulWidget {
  const PokedexScreen({super.key});

  @override
  State<PokedexScreen> createState() => _PokedexScreenState();
}

class _PokedexScreenState extends State<PokedexScreen> {
  final _service = PokemonService();
  final _controller = TextEditingController();
  late Future<Pokemon> _future;
  int _currentId = 1;

  @override
  void initState() {
    super.initState();
    _future = _service.getPokemon('1');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _load(String query) {
    if (query.trim().isEmpty) return;
    setState(() => _future = _service.getPokemon(query));
  }

  void _step(int delta) {
    final next = (_currentId + delta).clamp(1, 1025);
    _load(next.toString());
  }

  void _random() => _load((1 + DateTime.now().millisecondsSinceEpoch % 1025).toString());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pokédex'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _controller,
              textInputAction: TextInputAction.search,
              onSubmitted: _load,
              decoration: InputDecoration(
                hintText: 'Nombre o número (ej. pikachu, 25)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.arrow_forward),
                  onPressed: () => _load(_controller.text),
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<Pokemon>(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.error_outline, size: 64, color: Colors.red),
                          const SizedBox(height: 8),
                          Text(snap.error.toString().replaceFirst('Exception: ', ''),
                              textAlign: TextAlign.center),
                          const SizedBox(height: 12),
                          FilledButton(
                            onPressed: () => _load(_currentId.toString()),
                            child: const Text('Reintentar'),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                final p = snap.data!;
                _currentId = p.id;
                return _PokemonCard(pokemon: p);
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              OutlinedButton.icon(
                onPressed: () => _step(-1),
                icon: const Icon(Icons.chevron_left),
                label: const Text('Anterior'),
              ),
              FilledButton.icon(
                onPressed: _random,
                icon: const Icon(Icons.casino),
                label: const Text('Aleatorio'),
              ),
              OutlinedButton.icon(
                onPressed: () => _step(1),
                icon: const Icon(Icons.chevron_right),
                label: const Text('Siguiente'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PokemonCard extends StatelessWidget {
  final Pokemon pokemon;
  const _PokemonCard({required this.pokemon});

  @override
  Widget build(BuildContext context) {
    final main = typeColor(pokemon.types.first);
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Card(
        clipBehavior: Clip.antiAlias,
        elevation: 4,
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: main.withOpacity(0.25),
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text('#${pokemon.id.toString().padLeft(3, '0')}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Image.network(
                    pokemon.imageUrl,
                    height: 220,
                    loadingBuilder: (c, child, prog) => prog == null
                        ? child
                        : const SizedBox(
                            height: 220,
                            child: Center(child: CircularProgressIndicator())),
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.catching_pokemon, size: 120),
                  ),
                  Text(pokemon.displayName,
                      style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: pokemon.types
                        .map((t) => Chip(
                              label: Text(t,
                                  style: const TextStyle(color: Colors.white)),
                              backgroundColor: typeColor(t),
                            ))
                        .toList(),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _info('Altura', '${pokemon.height} m'),
                      _info('Peso', '${pokemon.weight} kg'),
                    ],
                  ),
                  const Divider(height: 32),
                  const Text('Habilidades',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  Text(pokemon.abilities.join(', ')),
                  const SizedBox(height: 16),
                  const Text('Estadísticas base',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  ...pokemon.stats.map((s) => _statBar(s, main)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _info(String label, String value) => Column(children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.grey)),
      ]);

  Widget _statBar(PokemonStat s, Color color) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            SizedBox(width: 110, child: Text(s.name)),
            SizedBox(width: 36, child: Text('${s.value}')),
            Expanded(
              child: LinearProgressIndicator(
                value: (s.value / 255).clamp(0.0, 1.0),
                color: color,
                minHeight: 8,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ],
        ),
      );
}
